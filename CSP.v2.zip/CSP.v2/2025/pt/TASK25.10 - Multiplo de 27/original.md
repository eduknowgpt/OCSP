# Multiplo de 27

Faça um programa em linguagem C que peça para o usuário informar um número inteiro e positivo. Verifique se o número digitado é múltiplo de 27.